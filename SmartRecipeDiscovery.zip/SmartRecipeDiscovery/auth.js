/* Smart Recipe Discovery - client-side auth (demo only: data stays in this browser) */
const SRDAuth=(function(){
const USERS="srd-users",SESSION="srd-session",mem={};
function get(k,d){try{const v=localStorage.getItem(k);if(v!==null)return JSON.parse(v)}catch(e){}return k in mem?mem[k]:d}
function set(k,v){mem[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function del(k){delete mem[k];try{localStorage.removeItem(k)}catch(e){}}
async function hash(s){
  try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode("srd:"+s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}}catch(e){}
  let h=5381;for(const c of "srd:"+s)h=((h<<5)+h+c.charCodeAt(0))|0;return"f"+(h>>>0).toString(16)}
const norm=e=>String(e||"").trim().toLowerCase();
const emailOk=e=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
return{
  current(){return get(SESSION,null)},
  async signup(name,email,pw,pw2){
    name=String(name||"").trim();email=norm(email);
    if(name.length<2)return{ok:false,error:"Please enter your full name."};
    if(!emailOk(email))return{ok:false,error:"Enter a valid email address."};
    if(pw.length<6)return{ok:false,error:"Password must be at least 6 characters."};
    if(pw!==pw2)return{ok:false,error:"Passwords do not match."};
    const users=get(USERS,{});
    if(users[email])return{ok:false,error:"An account with this email already exists. Please log in."};
    users[email]={name,email,hash:await hash(pw),created:Date.now()};
    set(USERS,users);return{ok:true,email};
  },
  async login(email,pw){
    email=norm(email);
    if(!emailOk(email)||!pw)return{ok:false,error:"Enter your email and password."};
    const u=get(USERS,{})[email];
    if(!u||u.hash!==await hash(pw))return{ok:false,error:"Incorrect email or password."};
    set(SESSION,{name:u.name,email:u.email});return{ok:true};
  },
  logout(){del(SESSION);location.replace("login.html")},
  requireAuth(){ // call at top of protected pages
    const s=this.current();
    if(!s){document.documentElement.style.visibility="hidden";location.replace("login.html")}
    return s;
  },
  redirectIfAuth(){if(this.current())location.replace("index.html")}
};})();
